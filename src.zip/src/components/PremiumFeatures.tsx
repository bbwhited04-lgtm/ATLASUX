import { PremiumHub } from './premium/PremiumHub';

export function PremiumFeatures() {
  return <PremiumHub />;
}