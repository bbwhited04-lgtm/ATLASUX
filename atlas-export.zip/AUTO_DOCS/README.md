# AUTO_DOCS

These files are auto-generated documentation to help with review, onboarding, and Alpha test planning.

- `TREE.md` — a quick directory tree snapshot.
- `FILE_INDEX.md` — a navigable index of files with short summaries.

Generated on: 2026-02-22T14:51:16.753446Z
