import { MobileApp } from "../components/MobileApp";

export default function MobilePage() {
  return <MobileApp />;
}
