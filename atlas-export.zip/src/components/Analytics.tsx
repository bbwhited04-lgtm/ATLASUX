import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  BarChart3,
  RefreshCw,
  Download,
  Users,
  Eye,
  MousePointerClick,
  Clock,
  Heart,
  TrendingUp,
  TrendingDown,
  Globe,
  Smartphone
} from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
// Connections are handled by the Integrations wizard (trusted flow)

export function Analytics() {
  const navigate = useNavigate();
  const [timeRange, setTimeRange] = useState("7d");
  const [activeTab, setActiveTab] = useState("overview");
  
  // No connected accounts - all data is empty
  const websiteData: any[] = [];
  
  // Social Media Metrics
  const socialData: any[] = [];
  
  const engagementData: any[] = [];
  
  const trafficSources: any[] = [];
  
  const topPages: any[] = [];
  
  // Route to the shared Integrations flow (Sprout-style)
  const handleConnectPlatform = (platformName: string) => {
    navigate(`/app/integrations?focus=${encodeURIComponent(platformName)}`);
  };
  
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent flex items-center gap-2">
            <BarChart3 className="w-6 h-6 text-cyan-400" />
            Analytics Dashboard
          </h2>
          <p className="text-slate-400 text-sm mt-1">
            Track website, social media, and business metrics
          </p>
        </div>
        
        <div className="flex gap-2">
          <div className="flex border border-cyan-500/20 rounded-lg overflow-hidden">
            {["24h", "7d", "30d", "90d"].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 py-1.5 text-xs transition-colors ${
                  timeRange === range 
                    ? "bg-cyan-500/20 text-cyan-400" 
                    : "text-slate-400 hover:bg-slate-800"
                }`}
              >
                {range}
              </button>
            ))}
          </div>
          
          <Button variant="outline" className="border-cyan-500/20">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
          
          <Button variant="outline" className="border-cyan-500/20">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>
      
      {/* Key Metrics */}
      <div className="grid grid-cols-5 gap-4">
        <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-blue-400" />
            </div>
            <Badge variant="outline" className="border-slate-500/40 text-slate-400 text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              +0%
            </Badge>
          </div>
          <div className="text-2xl font-bold">0</div>
          <div className="text-xs text-slate-400 mt-1">Total Visitors</div>
        </Card>
        
        <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
              <Eye className="w-5 h-5 text-purple-400" />
            </div>
            <Badge variant="outline" className="border-slate-500/40 text-slate-400 text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              +0%
            </Badge>
          </div>
          <div className="text-2xl font-bold">0</div>
          <div className="text-xs text-slate-400 mt-1">Page Views</div>
        </Card>
        
        <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="w-10 h-10 rounded-lg bg-cyan-500/20 flex items-center justify-center">
              <MousePointerClick className="w-5 h-5 text-cyan-400" />
            </div>
            <Badge variant="outline" className="border-slate-500/40 text-slate-400 text-xs">
              <TrendingDown className="w-3 h-3 mr-1" />
              0%
            </Badge>
          </div>
          <div className="text-2xl font-bold">0%</div>
          <div className="text-xs text-slate-400 mt-1">Click Rate</div>
        </Card>
        
        <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
              <Clock className="w-5 h-5 text-green-400" />
            </div>
            <Badge variant="outline" className="border-slate-500/40 text-slate-400 text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              +0%
            </Badge>
          </div>
          <div className="text-2xl font-bold">0:00</div>
          <div className="text-xs text-slate-400 mt-1">Avg. Session</div>
        </Card>
        
        <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
              <Heart className="w-5 h-5 text-pink-400" />
            </div>
            <Badge variant="outline" className="border-slate-500/40 text-slate-400 text-xs">
              <TrendingUp className="w-3 h-3 mr-1" />
              +0%
            </Badge>
          </div>
          <div className="text-2xl font-bold">0</div>
          <div className="text-xs text-slate-400 mt-1">Social Followers</div>
        </Card>
      </div>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-slate-900/50 border border-cyan-500/20">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="website">Website Analytics</TabsTrigger>
          <TabsTrigger value="social">Social Media</TabsTrigger>
          <TabsTrigger value="traffic">Traffic Sources</TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {/* Visitors Chart */}
            <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Website Traffic</h3>
                <Badge variant="outline" className="border-cyan-500/20">
                  Google Analytics
                </Badge>
              </div>
              
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={websiteData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#94a3b8" style={{ fontSize: 12 }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: '1px solid #334155',
                      borderRadius: '8px'
                    }} 
                  />
                  <Legend />
                  <Line type="monotone" dataKey="visitors" stroke="#06b6d4" strokeWidth={2} />
                  <Line type="monotone" dataKey="pageviews" stroke="#8b5cf6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </Card>
            
            {/* Social Engagement */}
            <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
              <h3 className="font-semibold mb-4">Social Media Engagement</h3>
              
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={engagementData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#94a3b8" style={{ fontSize: 12 }} />
                  <YAxis stroke="#94a3b8" style={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: '1px solid #334155',
                      borderRadius: '8px'
                    }} 
                  />
                  <Legend />
                  <Bar dataKey="likes" fill="#ec4899" />
                  <Bar dataKey="comments" fill="#06b6d4" />
                  <Bar dataKey="shares" fill="#8b5cf6" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>
          
          {/* Social Platforms Performance */}
          <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
            <h3 className="font-semibold mb-4">Platform Performance</h3>
            
            <div className="space-y-3">
              {socialData.map((platform) => (
                <div key={platform.platform} className="flex items-center gap-4">
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${platform.color}20` }}
                  >
                    <div 
                      className="w-4 h-4 rounded"
                      style={{ backgroundColor: platform.color }}
                    />
                  </div>
                  
                  <div className="flex-1 grid grid-cols-4 gap-4">
                    <div>
                      <div className="font-medium text-sm">{platform.platform}</div>
                      <div className="text-xs text-slate-400">{platform.posts} posts</div>
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium">{platform.followers.toLocaleString()}</div>
                      <div className="text-xs text-slate-400">Followers</div>
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium text-green-400">{platform.engagement}%</div>
                      <div className="text-xs text-slate-400">Engagement</div>
                    </div>
                    
                    <div className="flex justify-end">
                      <Button size="sm" variant="outline" className="text-xs border-cyan-500/20">
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
        
        {/* Website Analytics Tab */}
        <TabsContent value="website" className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <Card className="col-span-2 bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
              <h3 className="font-semibold mb-4">Sessions & Page Views</h3>
              
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={websiteData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="date" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: '1px solid #334155',
                      borderRadius: '8px'
                    }} 
                  />
                  <Legend />
                  <Line type="monotone" dataKey="sessions" stroke="#06b6d4" strokeWidth={2} />
                  <Line type="monotone" dataKey="pageviews" stroke="#8b5cf6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </Card>
            
            <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
              <h3 className="font-semibold mb-4">Device Breakdown</h3>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-cyan-400" />
                      <span>Mobile</span>
                    </div>
                    <span className="font-medium">58%</span>
                  </div>
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-500" style={{ width: "58%" }} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Globe className="w-4 h-4 text-purple-400" />
                      <span>Desktop</span>
                    </div>
                    <span className="font-medium">35%</span>
                  </div>
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500" style={{ width: "35%" }} />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-pink-400" />
                      <span>Tablet</span>
                    </div>
                    <span className="font-medium">7%</span>
                  </div>
                  <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-pink-500" style={{ width: "7%" }} />
                  </div>
                </div>
              </div>
            </Card>
          </div>
          
          {/* Top Pages */}
          <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
            <h3 className="font-semibold mb-4">Top Performing Pages</h3>
            
            <div className="space-y-2">
              {topPages.map((page, idx) => (
                <div 
                  key={idx}
                  className="flex items-center gap-4 p-3 rounded-lg bg-slate-800/50 hover:bg-slate-800 transition-colors"
                >
                  <div className="w-8 text-center">
                    <span className="text-2xl font-bold text-slate-600">#{idx + 1}</span>
                  </div>
                  
                  <div className="flex-1 grid grid-cols-4 gap-4">
                    <div className="col-span-2">
                      <div className="font-medium text-sm text-slate-200">{page.page}</div>
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium">{page.views.toLocaleString()}</div>
                      <div className="text-xs text-slate-400">Views</div>
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium">{page.avgTime}</div>
                      <div className="text-xs text-slate-400">Avg. Time</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </TabsContent>
        
        {/* Social Media Tab */}
        <TabsContent value="social" className="space-y-4">
          <div className="grid grid-cols-5 gap-4">
            {socialData.map((platform) => (
              <Card 
                key={platform.platform}
                className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-4"
              >
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
                  style={{ backgroundColor: `${platform.color}20` }}
                >
                  <div 
                    className="w-6 h-6 rounded"
                    style={{ backgroundColor: platform.color }}
                  />
                </div>
                
                <div className="font-medium mb-1">{platform.platform}</div>
                <div className="text-2xl font-bold mb-1">{platform.followers.toLocaleString()}</div>
                <div className="text-xs text-slate-400 mb-3">Followers</div>
                
                <div className="text-sm text-green-400">+{platform.engagement}% engagement</div>
              </Card>
            ))}
          </div>
          
          <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
            <h3 className="font-semibold mb-4">Engagement Trends</h3>
            
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="date" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1e293b', 
                    border: '1px solid #334155',
                    borderRadius: '8px'
                  }} 
                />
                <Legend />
                <Bar dataKey="likes" fill="#ec4899" />
                <Bar dataKey="comments" fill="#06b6d4" />
                <Bar dataKey="shares" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>
        
        {/* Traffic Sources Tab */}
        <TabsContent value="traffic" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
              <h3 className="font-semibold mb-4">Traffic Distribution</h3>
              
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={trafficSources}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {trafficSources.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </Card>
            
            <Card className="bg-slate-900/50 border-cyan-500/20 backdrop-blur-xl p-6">
              <h3 className="font-semibold mb-4">Traffic Sources Breakdown</h3>
              
              <div className="space-y-4">
                {trafficSources.map((source) => (
                  <div key={source.name} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>{source.name}</span>
                      <span className="font-medium">{source.value}%</span>
                    </div>
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div 
                        className="h-full transition-all"
                        style={{ 
                          width: `${source.value}%`,
                          backgroundColor: source.color
                        }} 
                      />
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Google Analytics Connection */}
      <Card className="bg-gradient-to-br from-blue-500/10 to-cyan-500/10 border-cyan-500/30 backdrop-blur-xl p-6">
        <div className="flex items-start gap-4">
          <BarChart3 className="w-12 h-12 text-cyan-400 flex-shrink-0" />
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h4 className="font-semibold">Connect Analytics Platforms</h4>
              <Badge variant="outline" className="border-red-500/40 text-red-400 text-xs">
                0 Connected
              </Badge>
            </div>
            <p className="text-sm text-slate-300 mb-4">
              Import data from multiple analytics platforms to get a unified view of your performance across web, social, e-commerce, and more.
            </p>
            
            {/* Analytics Platform Categories */}
            <div className="space-y-4">
              {/* Web Analytics */}
              <div>
                <div className="text-xs font-semibold text-cyan-400 uppercase tracking-wider mb-2">Web Analytics</div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Globe className="w-3 h-3 mr-1" />
                    Google Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Globe className="w-3 h-3 mr-1" />
                    Adobe Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Globe className="w-3 h-3 mr-1" />
                    Matomo
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Globe className="w-3 h-3 mr-1" />
                    Mixpanel
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Globe className="w-3 h-3 mr-1" />
                    Plausible
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Globe className="w-3 h-3 mr-1" />
                    Heap Analytics
                  </Button>
                </div>
              </div>
              
              {/* E-commerce Analytics */}
              <div>
                <div className="text-xs font-semibold text-green-400 uppercase tracking-wider mb-2">E-commerce Analytics</div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Shopify Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    WooCommerce
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Amazon Seller Central
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Etsy Stats
                  </Button>
                </div>
              </div>
              
              {/* Marketing & Ads Analytics */}
              <div>
                <div className="text-xs font-semibold text-purple-400 uppercase tracking-wider mb-2">Marketing & Advertising</div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Google Ads
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Facebook Ads Manager
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    HubSpot Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Mailchimp Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    SEMrush
                  </Button>
                </div>
              </div>
              
              {/* Social Media Analytics */}
              <div>
                <div className="text-xs font-semibold text-pink-400 uppercase tracking-wider mb-2">Social Media Analytics</div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Heart className="w-3 h-3 mr-1" />
                    Facebook Insights
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Heart className="w-3 h-3 mr-1" />
                    Instagram Insights
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Heart className="w-3 h-3 mr-1" />
                    Twitter Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Heart className="w-3 h-3 mr-1" />
                    LinkedIn Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Heart className="w-3 h-3 mr-1" />
                    TikTok Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Heart className="w-3 h-3 mr-1" />
                    YouTube Analytics
                  </Button>
                </div>
              </div>
              
              {/* Payment & Financial Analytics */}
              <div>
                <div className="text-xs font-semibold text-yellow-400 uppercase tracking-wider mb-2">Payment & Financial</div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Stripe Dashboard
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    PayPal Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Square Analytics
                  </Button>
                </div>
              </div>
              
              {/* App Analytics */}
              <div>
                <div className="text-xs font-semibold text-blue-400 uppercase tracking-wider mb-2">Mobile & App Analytics</div>
                <div className="flex flex-wrap gap-2">
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Smartphone className="w-3 h-3 mr-1" />
                    Firebase Analytics
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Smartphone className="w-3 h-3 mr-1" />
                    Amplitude
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Smartphone className="w-3 h-3 mr-1" />
                    App Annie
                  </Button>
                  <Button size="sm" variant="outline" className="text-xs border-cyan-500/20 hover:bg-cyan-500/10">
                    <Smartphone className="w-3 h-3 mr-1" />
                    Flurry Analytics
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-cyan-500/20">
              <p className="text-xs text-slate-400">
                💡 <strong>Tip:</strong> Connect multiple analytics sources to get a complete picture. All data will be unified in your Analytics Dashboard above.
              </p>
            </div>
          </div>
        </div>
      </Card>
    </div>
  );
}