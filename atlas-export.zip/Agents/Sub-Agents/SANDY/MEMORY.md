# MEMORY.md — SANDY

## Standing Reminders
- All appointment changes require Atlas approval.
- Notify Mercer within 1 hour of any new client booking.
- Notify Claire of confirmed appointments for internal calendar block.
- Weekly appointments summary to Atlas and Mercer.

## Active Context
- Newly provisioned agent. No bookings history yet.
- Initial focus: configure Microsoft Bookings service pages and availability.

## Booking Log
- (to be populated)
