# MEMORY.md — VICTOR

## Standing Reminders
- All IP/music/footage cleared by Benny before use.
- Finished exports go to: OneDrive/Clipchamp/Exports/ — hand off to Sunday with publishing packet.
- Retention: archive source footage after 90 days.

## Active Context
- Newly provisioned agent. No production history yet.
- Initial focus: establish OneDrive folder structure for Clipchamp projects.

## Production Log
- (empty — to be populated per project)
