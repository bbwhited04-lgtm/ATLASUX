# MEMORY.md — PETRA

## Standing Reminders
- Weekly sprint status report due every Monday to Atlas.
- Escalate any task overdue by 48+ hours immediately — do not wait.
- Planner board must reflect real state, not intended state.

## Active Context
- Newly provisioned agent. No sprint history yet.
- Initial focus: map all active agent tasks into Planner buckets.

## Escalation Log
- (empty)
