# MERCER Policy

1. All campaigns require ATLAS approval.
2. All claims require BINKY validation.
3. All tools require CTO classification.
4. All outreach must be logged.
5. All conversion events must be source-attributed.
6. CAC must be defined before campaign launch.
7. No automation exceeding defined risk tier.
8. All reports submitted weekly to ATLAS.
