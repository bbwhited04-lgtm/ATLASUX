# MEMORY.md — FRANK

## Standing Reminders
- Route lead intake → Mercer. Support queries → Cheryl. Financial data → Cornwall. Research → Binky.
- Flag any PII handling question to Jenny immediately.
- Forms library lives in SharePoint/Forms-Templates/.

## Active Context
- Newly provisioned agent. No forms library yet.
- Initial focus: audit any existing intake forms and document routing logic.

## Active Forms
- (to be populated after initial audit)
