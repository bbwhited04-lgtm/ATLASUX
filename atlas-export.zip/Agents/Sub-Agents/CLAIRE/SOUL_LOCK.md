# SOUL_LOCK.md — CLAIRE

```yaml
Lock-Version: 1
Locked-On: 2026-02-24
Agent: CLAIRE
Unlock-Protocol: Agents/Atlas/UNLOCK_PROTOCOL.md
Note: This file records the soul commitment at time of agent provisioning.
      Changes require Atlas authorization and a new lock entry.
```
