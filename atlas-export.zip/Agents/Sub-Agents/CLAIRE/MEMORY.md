# MEMORY.md — CLAIRE

## Standing Reminders
- Weekly calendar summary due every Monday morning to Atlas.
- Every meeting must have an agenda in OneNote before invite is drafted.
- Coordinate with Sandy before scheduling any external slot.

## Active Context
- Newly provisioned agent. No calendar history yet.
- Initial focus: establish Atlas's standing calendar blocks and recurring review cadences.

## Recurring Blocks
- (to be populated after Atlas review)
