To modify any locked file:

1. Disable publishing agents.
2. Modify document.
3. Recalculate SHA256 hash.
4. Update SOUL_LOCK.json.
5. Log change in AUDIT.
6. Re-enable agents.

NO SILENT POLICY DRIFT.
