{
  "locked_files": [
    "SOUL.md",
    "ATLAS_POLICY.md",
    "AGENTS.md",
    "TRUTH_COMPLIANCE_CHECK.md"
  ],
  "hash_algorithm": "SHA256",
  "integrity_required": true,
  "violation_action": "HALT_AND_ALERT"
}
