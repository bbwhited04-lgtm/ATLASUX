Email address: atlas@deadappcorp.org
password for email address: zxWr89$huF22
BINKY email address: binky@deadappcorp.org
SUNDAY email address: sunday@deadappcorp.org
TINA email address: tina@deadappcorp.org
LARRY email address: larry@deadappcorp.org
JENNY email address: jenny@deadappcorp.org
BENNY email address: benny@deadappcorp.org
ARCHY email address: archy@deadappcorp.org
CORNWALL email address: cornwall@deadappcorp.org
DONNA email address: donna@deadappcorp.org
DWIGHT email address: dwight@deadappcorp.org
EMMA email address: emma@deadappcorp.org
FRAN email address: fran@deadappcorp.org
KELLY email address: kelly@deadappcorp.org
LINK email address: link@deadappcorp.org
PENNY email address: penny@deadappcorp.org
REYNOLDS email address: reynolds@deadappcorp.org
TERRY email address: terry@deadappcorp.org
TIMMY email address: timmy@deadappcorp.org
POSTMASTER email address: postmaster@deadappcorp.org
ABUSE email address: abuse@deadappcorp.org
