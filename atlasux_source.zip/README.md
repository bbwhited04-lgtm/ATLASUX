
  # Atlas UX PC App Design

  This is a code bundle for Atlas UX PC App Design. The original project is available at https://www.figma.com/design/jtyH9IZHMsKHcKhWml8cjn/Atlas-UX-PC-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  