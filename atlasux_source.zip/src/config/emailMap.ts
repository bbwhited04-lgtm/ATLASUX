export const agentEmails = {
  // NOTE: ATLAS is the only licensed mailbox. Everyone else is a shared inbox with Send As delegated to ATLAS.
  ATLAS: "atlas@deadapp.info",

  // Executive staff / core agents
  BINKY: "binky.cro@deadapp.info",
  BENNY: "benny.cto@deadapp.info",
  TINA: "tina.cfo@deadapp.info",
  LARRY: "larry.auditor@deadapp.info",
  JENNY: "jenny.clo@deadapp.info",

  // BINKY sub-agents / publishers
  ARCHY: "archy.binkypro@deadapp.info",
  VENNY: "venny.videographer@deadapp.info",
  PENNY: "penny.facebook@deadapp.info",
  CORNWALL: "cornwall.pinterest@deadapp.info",
  DONNA: "donna.redditor@deadapp.info",
  DWIGHT: "dwight.threads@deadapp.info",
  EMMA: "emma.alignable@deadapp.info",
  FRAN: "fran.facebook@deadapp.info",
  KELLY: "kelly.x@deadapp.info",
  LINK: "link.linkedin@deadapp.info",
  REYNOLDS: "reynolds.blogger@deadapp.info",
  SUNDAY: "sunday.teambinky@deadapp.info",
  TERRY: "terry.tumblr@deadapp.info",

  // Support & admin
  CHERYL: "support@deadapp.info",
  POSTMASTER: "postmaster@deadapp.info",
  ABUSE: "abuse@deadapp.info",

  // Not yet provisioned (placeholder so UI + workflows don't break)
  DAILY_INTEL: "atlas@deadapp.info",
  TIMMY: "atlas@deadapp.info",
} as const;

export type AgentEmailKey = keyof typeof agentEmails;
